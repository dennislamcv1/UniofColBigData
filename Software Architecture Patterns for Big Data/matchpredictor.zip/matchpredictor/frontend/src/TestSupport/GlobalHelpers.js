require('whatwg-fetch');
require('@testing-library/jest-dom')

console.error = () => undefined;
console.log = () => undefined;
console.info = () => undefined;
