from typing import Iterable, List
import numpy as np
from sklearn.linear_model import LogisticRegression
from matchpredictor.matchresults.result import Outcome, Fixture, Result, Team
from matchpredictor.predictors.predictor import Predictor, Prediction


class FormBasedPredictor(Predictor):
    def __init__(self, model: LogisticRegression, teams: List[Team], fixtures: List[Fixture], outcomes: List[Outcome]) -> None:
        self.model = model
        self.teams = {team.name: team for team in teams}
        self.fixtures = fixtures
        self.outcomes = outcomes
        self.team_indices = {team.name: i for i, team in enumerate(teams)}

    def _extract_features(self, fixture: Fixture) -> np.ndarray:
        # Extract basic features: home team points, away team points, goal difference, and form
        home_idx = self.team_indices[fixture.home_team.name]
        away_idx = self.team_indices[fixture.away_team.name]

        # Dummy features for this example, you'd replace this with actual data
        # Feature vector: [home_team_points, away_team_points, goal_difference, home_advantage]
        home_advantage = 1  # Bias for the home team
        home_points = 1.0  # Replace with actual points
        away_points = 1.0  # Replace with actual points
        goal_difference = home_points - away_points

        features = np.array([home_points, away_points, goal_difference, home_advantage])
        return features

    def predict(self, fixture: Fixture) -> Prediction:
        features = self._extract_features(fixture).reshape(1, -1)
        probabilities = self.model.predict_proba(features)[0]
        outcome_index = np.argmax(probabilities)
        outcome = [Outcome.HOME, Outcome.DRAW, Outcome.AWAY][outcome_index]
        confidence = probabilities[outcome_index]
        return Prediction(outcome, confidence)


def train_form_based_predictor(results: Iterable[Result], teams: List[Team]) -> Predictor:
    fixtures = [result.fixture for result in results]
    outcomes = [result.outcome for result in results]
    labels = np.array([0 if outcome == Outcome.HOME else 1 if outcome == Outcome.DRAW else 2 for outcome in outcomes])

    X = []
    for fixture in fixtures:
        home_points = 1.0  # Replace with actual points
        away_points = 1.0  # Replace with actual points
        goal_difference = home_points - away_points
        home_advantage = 1  # Bias for the home team

        X.append([home_points, away_points, goal_difference, home_advantage])

    X = np.array(X)
    model = LogisticRegression(multi_class='multinomial', max_iter=1000)
    model.fit(X, labels)

    return FormBasedPredictor(model, teams, fixtures, outcomes)
