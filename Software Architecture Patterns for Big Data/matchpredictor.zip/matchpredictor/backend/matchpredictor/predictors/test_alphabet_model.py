# backend/test/predictors/test_alphabet_model.py

import unittest
from matchpredictor.matchresults.result import Fixture, Outcome, Scenario
from predictor import InProgressPredictor, Prediction

class AlphabetModel(InProgressPredictor):
    def predict(self, fixture: Fixture) -> Prediction:
        # Simple dummy implementation, always predicts Outcome.DRAW
        return Prediction(outcome=Outcome.DRAW, confidence=0.33)
    
    def predict_in_progress(self, fixture: Fixture, scenario: Scenario) -> Prediction:
        # Another dummy implementation for in-progress games
        return Prediction(outcome=Outcome.DRAW, confidence=0.33)

class TestAlphabetModel(unittest.TestCase):
    def setUp(self):
        self.model = AlphabetModel()

    def test_predict_accuracy(self):
        # Dummy fixtures and expected outcomes
        fixtures = [
            Fixture("Team A", "Team B"),
            Fixture("Team C", "Team D"),
            Fixture("Team E", "Team F"),
        ]
        
        expected_outcomes = [
            Outcome.HOME_WIN,
            Outcome.AWAY_WIN,
            Outcome.DRAW,  # Only this should match the predicted outcome
        ]

        correct_predictions = 0
        for fixture, expected_outcome in zip(fixtures, expected_outcomes):
            prediction = self.model.predict(fixture)
            if prediction.outcome == expected_outcome:
                correct_predictions += 1

        # Calculate accuracy
        accuracy = correct_predictions / len(fixtures)
        
        # Test for approximately 33% accuracy
        self.assertAlmostEqual(accuracy, 0.33, delta=0.05)

    def test_predict_in_progress_accuracy(self):
        # Dummy fixtures, scenarios, and expected outcomes
        fixtures = [
            Fixture("Team G", "Team H"),
            Fixture("Team I", "Team J"),
            Fixture("Team K", "Team L"),
        ]
        
        scenarios = [
            Scenario(half_time_score=(0, 1)),
            Scenario(half_time_score=(1, 0)),
            Scenario(half_time_score=(0, 0)),
        ]
        
        expected_outcomes = [
            Outcome.HOME_WIN,
            Outcome.AWAY_WIN,
            Outcome.DRAW,  # Only this should match the predicted outcome
        ]

        correct_predictions = 0
        for fixture, scenario, expected_outcome in zip(fixtures, scenarios, expected_outcomes):
            prediction = self.model.predict_in_progress(fixture, scenario)
            if prediction.outcome == expected_outcome:
                correct_predictions += 1

        # Calculate accuracy
        accuracy = correct_predictions / len(fixtures)
        
        # Test for approximately 33% accuracy
        self.assertAlmostEqual(accuracy, 0.33, delta=0.05)

if __name__ == '__main__':
    unittest.main()
