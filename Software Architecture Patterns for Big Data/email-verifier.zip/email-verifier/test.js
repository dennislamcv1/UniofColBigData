import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
    vus: 10,           // Number of virtual users
    duration: '30s',   // Duration of the test
};

export default function () {
    const url = 'http://localhost:8081/request-registration';
    const payload = JSON.stringify({ email: 'test@example.com' });

    const params = {
        headers: {
            'Content-Type': 'application/json',
        },
    };

    const res = http.post(url, payload, params);

    check(res, {
        'status is 200': (r) => r.status === 200,
    });

    sleep(1);
}
