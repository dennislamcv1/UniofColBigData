from unittest import TestCase
from matchpredictor.matchresults.results_provider import validation_results
from matchpredictor.evaluation.evaluator import Evaluator
from matchpredictor.predictors.home_predictor import HomePredictor
from test.predictors import csv_location

class TestHomePredictor(TestCase):
    def test_accuracy(self) -> None:
        # Load validation data for the year 2019
        validation_data = validation_results(csv_location, 2019)
        
        # Create an evaluator instance with the HomePredictor
        evaluator = Evaluator(HomePredictor())
        
        # Measure accuracy of the HomePredictor using the validation data
        accuracy, _ = evaluator.measure_accuracy(validation_data)
        
        # Assert that the accuracy is at least 33%
        self.assertGreaterEqual(accuracy, .33)

# To run the test, ensure you have a test runner setup, for example, using:
# python -m unittest discover -s backend/test/predictors -p "*.py"

