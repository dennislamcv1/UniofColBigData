# backend/matchpredictor/predictors/sophisticated_predictor.py

from typing import Optional
from dataclasses import dataclass
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
import numpy as np

from matchpredictor.matchresults.result import Fixture, Outcome
from matchpredictor.predictors.predictor import Predictor, Prediction

@dataclass
class TrainedModel:
    model: LogisticRegression
    label_encoder: LabelEncoder

class SophisticatedPredictor(Predictor):
    def __init__(self, trained_model: TrainedModel):
        self.trained_model = trained_model

    def predict(self, fixture: Fixture) -> Prediction:
        features = self._extract_features(fixture)
        probabilities = self.trained_model.model.predict_proba([features])[0]
        predicted_class = np.argmax(probabilities)
        outcome = self.trained_model.label_encoder.inverse_transform([predicted_class])[0]
        confidence = probabilities[predicted_class]
        return Prediction(outcome=outcome, confidence=confidence)

    def _extract_features(self, fixture: Fixture):
        # Extract relevant features from the fixture
        return [
            hash(fixture.home_team) % 1000,
            hash(fixture.away_team) % 1000,
            fixture.date.month,
        ]

def train_sophisticated_predictor(training_data):
    X = []
    y = []
    for result in training_data:
        features = [
            hash(result.fixture.home_team) % 1000,
            hash(result.fixture.away_team) % 1000,
            result.fixture.date.month,
        ]
        X.append(features)
        y.append(result.outcome)

    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)
    model = LogisticRegression()
    model.fit(X, y_encoded)

    return TrainedModel(model=model, label_encoder=label_encoder)
