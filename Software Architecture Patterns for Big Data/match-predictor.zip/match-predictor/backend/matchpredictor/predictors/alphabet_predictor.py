# backend/matchpredictor/predictors/alphabet_predictor.py

from typing import Optional
from dataclasses import dataclass
from matchpredictor.matchresults.result import Fixture, Outcome
from matchpredictor.predictors.predictor import Predictor, Prediction

class AlphabetPredictor(Predictor):
    def predict(self, fixture: Fixture) -> Prediction:
        # Simple alphabet-based prediction logic
        home_team = fixture.home_team
        away_team = fixture.away_team
        
        if home_team[0].lower() < away_team[0].lower():
            outcome = Outcome.HOME_WIN
        elif home_team[0].lower() > away_team[0].lower():
            outcome = Outcome.AWAY_WIN
        else:
            outcome = Outcome.DRAW

        # Confidence is set to None for this simplistic model
        return Prediction(outcome=outcome, confidence=None)
