window.env = {
    enableUpcomingGames: 'true',
}
